package com.ejust.campusmap

import android.content.Context
import android.webkit.JavascriptInterface

/**
 * Exposed to the web app as `window.AndroidBridge`. app.js calls
 * AndroidBridge.postNotification(title, body) from fireClassReminder()
 * so class reminders show up as real Android notifications, since the
 * web Notification API is unavailable on file:// pages.
 */
class AndroidNotificationBridge(private val context: Context) {

    @JavascriptInterface
    fun postNotification(title: String, body: String) {
        NotificationHelper.show(context, title, body)
    }
}
