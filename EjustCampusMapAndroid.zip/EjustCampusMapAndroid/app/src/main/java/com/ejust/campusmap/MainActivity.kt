package com.ejust.campusmap

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Thin native shell around the E-JUST Campus Map web app.
 *
 * The actual app (index.html / styles.css / app.js) lives untouched in
 * app/src/main/assets and is loaded straight from there. This class only
 * does the native-Android glue: WebView setup with local storage enabled
 * (so the persistence feature actually persists), hardware back-button
 * support that talks to the app's own in-page navigation history, and a
 * small JS bridge so class reminders can fire as real Android notifications
 * instead of the browser Notification API (which doesn't work on file://
 * pages anyway).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val notifPermissionRequestCode = 1001

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        setContentView(webView)

        NotificationHelper.createChannel(this)
        maybeRequestNotificationPermission()

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true          // required: this is what makes localStorage persistence work
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        webView.addJavascriptInterface(AndroidNotificationBridge(this), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            // keep every navigation inside this WebView / the local asset bundle —
            // there is nowhere else for this app to go
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean = false
        }
        webView.webChromeClient = WebChromeClient()

        webView.loadUrl("file:///android_asset/index.html")

        // The web app is a single-page app that never creates real browser
        // history entries (it swaps screens via JS state, not navigation),
        // so WebView.canGoBack() alone can't drive the back button. Instead
        // we ask the page's own in-app navigation stack what to do, and only
        // fall back to exiting the app when it says there's nowhere left to go.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "(function(){ try { return window.goBackInApp ? String(window.goBackInApp()) : 'false'; } " +
                        "catch(e){ return 'false'; } })();"
                ) { result ->
                    val handledInApp = result?.trim('"') == "true"
                    if (!handledInApp) {
                        if (webView.canGoBack()) {
                            webView.goBack()
                        } else {
                            finish()
                        }
                    }
                }
            }
        })
    }

    private fun maybeRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), notifPermissionRequestCode
                )
            }
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
