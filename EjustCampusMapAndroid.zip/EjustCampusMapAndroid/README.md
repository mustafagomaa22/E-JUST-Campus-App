# E-JUST Campus Map — Android

A native Android shell around the existing E-JUST Campus Map web app
(`index.html` / `styles.css` / `app.js`). The web app itself is unchanged —
it lives untouched in `app/src/main/assets/` and runs inside a `WebView`.
Two small, additive things were added specifically so it behaves like a
real Android app instead of just "a website in a box":

1. **Persistence actually works.** `WebView` needs `domStorageEnabled = true`
   for `localStorage` to function at all — that's set in `MainActivity`.
2. **The hardware back button works properly.** The web app is a single-page
   app that never creates real browser history entries, so plain
   `WebView.canGoBack()` wouldn't do anything useful. `app.js` now keeps a
   small in-page navigation history (`navHistory` / `goBackInApp()`), and
   `MainActivity` asks the page what to do on every back-press before
   falling back to closing the app.
3. **Class reminders fire as real Android notifications.** The web
   `Notification` API doesn't work on `file://` pages (which is what a
   local WebView asset is), so `app.js` now checks for `window.AndroidBridge`
   first and calls it if present — that's a tiny Kotlin class
   (`AndroidNotificationBridge`) that posts a real notification through
   `NotificationManager`. On a plain desktop browser (or if you re-open the
   original web files directly), it silently falls back to the old
   web-Notification/in-app-toast behavior, so nothing broke.

Nothing else changed. Login, badges, schedule, study room booking, QR
check-in, dark mode, leaderboard — all identical to the web version.

## Opening the project

1. Android Studio → **Open** → select this folder (`EjustCampusMapAndroid`).
2. Let it sync. If it complains the Gradle wrapper jar is missing, that's
   normal for a hand-built project like this one — Android Studio will
   offer to download/generate it automatically (or: **File → Sync Project
   with Gradle Files**, or run `gradle wrapper` once from a terminal if you
   have Gradle installed).
3. Run on an emulator or a physical device (▶ button, or Shift+F10).
   `minSdk` is 26 (Android 8.0+), which covers effectively all real devices.

## Building an APK

`Build → Build Bundle(s) / APK(s) → Build APK(s)`, or from the command line:

```
./gradlew assembleDebug
```

The output APK lands in `app/build/outputs/apk/debug/`.

## Known limitations (being upfront about these)

- **Google Fonts need a network connection.** The app links to Google Fonts
  the same way the web version does. No internet → it falls back to the
  system font (already handled by the existing CSS `font-family` fallback
  chain), so nothing breaks, it just looks slightly different offline.
- **QR check-in is still simulated**, exactly like it was on the web — it's
  a canned scan animation, not a real camera/QR reader. Wiring up
  `CameraX` + ML Kit for an actual scanner is a reasonable next step but is
  a real feature addition, not part of this wrapper.
- **No app icon artwork was designed** — the launcher icon is a simple
  vector recreation of the in-app logo mark (red square, white layered
  diamond), not a polished icon. Easy to swap: replace
  `res/drawable/ic_launcher_foreground.xml` and
  `res/drawable/ic_launcher_background.xml`, or drop in real PNGs via
  Android Studio's **Image Asset** tool (right-click `res` → New → Image
  Asset).
- **Login is still fake**, same as the web version — any username/password
  is accepted. That was true before this wrapper and hasn't changed.
